import UIKit

func urunKontrolEtme1(urunAdi:String){
    
    if urunAdi == "Makarna" {
        print("Evet Makarna")
    } else
    { print ("Hayır Makarna Değil")
    }
}
    
urunKontrolEtme1(urunAdi: "Makarna")
//yukarıda olan kod else yapısı ile yazıldı ve true olduğu zaman çalıştı. Fakat ileri seviye swift ile guard yapısı if yapısının tam tersi olur. O da false olduğu zamanlarda çalışır.

//guard yapısını inceleyelim

func urunKontrolEtme2(urunAdi:String){
    guard urunAdi == "Makarna" else { //sadece false olduğu durumda çalışacağı için else direk guard satırında yazılır.
        print("Hayır Makarna Değil")
        return //return ile durdurarak çalışmadan çıkmamız gerekir.
    }
    print("Evet Makarna")
}
urunKontrolEtme1(urunAdi: "Ketçap")


